package com.loan.userservice.controller;

import com.loan.userservice.model.User;
import com.loan.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/signup")
    public ResponseEntity<Map<String, Object>> signup(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String password,
            @RequestParam String role,
            @RequestParam(required = false) String pin,
            @RequestParam(required = false) Integer creditScore) {
        Map<String, Object> response = userService.signup(name, email, password, role, pin, creditScore);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/signin")
    public ResponseEntity<String> signin(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String password = credentials.get("password");

        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            return ResponseEntity.badRequest().body("Email and password must not be empty");
        }

        String token = userService.signin(email, password);
        return ResponseEntity.ok(token);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        System.out.println("Fetching user with ID: " + id);
        User user = userService.getUserById(id);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}/credit-score")
    public ResponseEntity<Integer> getCreditScore(@PathVariable Long id) {
        System.out.println("Fetching credit score for user with ID: " + id);
        Integer creditScore = userService.getCreditScoreById(id);
        if (creditScore != null) {
            return ResponseEntity.ok(creditScore);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
