
package com.loan.userservice.repository;

import com.loan.userservice.model.FieldWorker;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FieldWorkerRepository extends JpaRepository<FieldWorker, Long> {
    boolean existsByEmail(String email);
    FieldWorker findByEmail(String email);
}
