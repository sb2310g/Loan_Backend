package com.loan.userservice.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {

    private final SecretKey secretKey;

    // Load the secret key from application.properties
    public JwtUtil(@Value("${jwt.secret}") String jwtSecret) {
        this.secretKey = Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }

    // Method to extract the user ID from the JWT
    public String extractUserId(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    // Method to extract the expiration date from the JWT
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

     //Method to extract the role from the JWT
    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class));
    }

    // Generic method to extract a claim from the JWT
    private <T> T extractClaim(String token, java.util.function.Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    // Method to extract all claims from the JWT
    private Claims extractAllClaims(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (JwtException e) {
            //  Log the error (optional)
            throw new JwtException("Invalid JWT: " + e.getMessage()); // Wrap JwtException
        }
    }

    // Method to check if the JWT has expired
    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    // Method to validate the JWT
    public boolean validateToken(String token) {
        try {
            extractAllClaims(token); // This will throw an exception if the token is invalid
            return !isTokenExpired(token);
        } catch (JwtException e) {
            return false;
        }
    }
}