package com.loan.userservice.service;

import com.loan.userservice.model.Admin;
import com.loan.userservice.model.FieldWorker;
import com.loan.userservice.model.User;
import com.loan.userservice.repository.AdminRepository;
import com.loan.userservice.repository.FieldWorkerRepository;
import com.loan.userservice.repository.UserRepository;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;  // Import the Value annotation
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {
    private static final String PIN = "1234";

    private final AdminRepository adminRepository;
    private final FieldWorkerRepository fieldWorkerRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final SecretKey secretKey;

    @Autowired
    public UserService(AdminRepository adminRepository, FieldWorkerRepository fieldWorkerRepository, UserRepository userRepository, PasswordEncoder passwordEncoder, @Value("${jwt.secret}") String jwtSecret) { // Inject jwtSecret
        this.adminRepository = adminRepository;
        this.fieldWorkerRepository = fieldWorkerRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.secretKey = Keys.hmacShaKeyFor(jwtSecret.getBytes()); // Initialize secretKey using the injected value
    }

    public Map<String, Object> signup(String name, String email, String password, String role, String pin, Integer creditScore) {
        if (adminRepository.existsByEmail(email) || fieldWorkerRepository.existsByEmail(email) || userRepository.existsByEmail(email)) {
            throw new RuntimeException("Email already exists");
        }

        Map<String, Object> response = new HashMap<>();
        if ("ADMIN".equalsIgnoreCase(role)) {
            if (!PIN.equals(pin)) {
                throw new RuntimeException("Invalid admin PIN");
            }
            Admin admin = new Admin(name, email, passwordEncoder.encode(password), "ADMIN", pin);
            adminRepository.save(admin);
            response.put("userId", admin.getId());
            response.put("role", admin.getRole());
        } else if ("FIELD_WORKER".equalsIgnoreCase(role)) {
            if (!PIN.equals(pin)) {
                throw new RuntimeException("Invalid field worker PIN");
            }
            FieldWorker fieldWorker = new FieldWorker(name, email, passwordEncoder.encode(password), "FIELD_WORKER", pin);
            fieldWorkerRepository.save(fieldWorker);
            response.put("userId", fieldWorker.getId());
            response.put("role", fieldWorker.getRole());
        } else if ("USER".equalsIgnoreCase(role)) {
            if (creditScore == null || creditScore < 300 || creditScore > 850) {
                throw new RuntimeException("Invalid credit score");
            }
            User user = new User(name, email, passwordEncoder.encode(password), "USER", creditScore);
            userRepository.save(user);
            response.put("userId", user.getId());
            response.put("role", user.getRole());
        } else {
            throw new RuntimeException("Invalid role");
        }
        return response;
    }

    public String signin(String email, String password) {
        // Check User table
        User user = userRepository.findByEmail(email);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return generateJwtToken(user.getId(), user.getRole());
        }

        // Check Admin table
        Admin admin = adminRepository.findByEmail(email);
        if (admin != null && passwordEncoder.matches(password, admin.getPassword())) {
            return generateJwtToken(admin.getId(), admin.getRole());
        }

        // Check Field Worker table
        FieldWorker fieldWorker = fieldWorkerRepository.findByEmail(email);
        if (fieldWorker != null && passwordEncoder.matches(password, fieldWorker.getPassword())) {
            return generateJwtToken(fieldWorker.getId(), fieldWorker.getRole());
        }

        // Log failure
        System.out.println("Signin failed for email: " + email);
        throw new RuntimeException("Invalid credentials");
    }

    private String generateJwtToken(Long userId, String role) {
        return Jwts.builder()
                .setSubject(userId.toString())
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000))
                .signWith(secretKey, SignatureAlgorithm.HS512)
                .compact();
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public Integer getCreditScoreById(Long id) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            return user.getCreditScore();
        }
        return null;
    }
}