package com.loan.userservice.security;

import com.loan.userservice.model.Admin;
import com.loan.userservice.model.FieldWorker;
import com.loan.userservice.model.User;
import com.loan.userservice.repository.AdminRepository;
import com.loan.userservice.repository.FieldWorkerRepository;
import com.loan.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;
    private final AdminRepository adminRepository;
    private final FieldWorkerRepository fieldWorkerRepository;

    @Autowired
    public UserDetailsServiceImpl(UserRepository userRepository, AdminRepository adminRepository, FieldWorkerRepository fieldWorkerRepository) {
        this.userRepository = userRepository;
        this.adminRepository = adminRepository;
        this.fieldWorkerRepository = fieldWorkerRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        // Try to find the user in each of the three tables
        Optional<User> userOptional = userRepository.findById(Long.parseLong(userId));
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            return buildUserDetails(user.getEmail(), user.getPassword(), user.getRole());
        }

        Optional<Admin> adminOptional = adminRepository.findById(Long.parseLong(userId));
        if (adminOptional.isPresent()) {
            Admin admin = adminOptional.get();
            return buildUserDetails(admin.getEmail(), admin.getPassword(), admin.getRole());
        }

        Optional<FieldWorker> fieldWorkerOptional = fieldWorkerRepository.findById(Long.parseLong(userId));
        if (fieldWorkerOptional.isPresent()) {
            FieldWorker fieldWorker = fieldWorkerOptional.get();
            return buildUserDetails(fieldWorker.getEmail(), fieldWorker.getPassword(), fieldWorker.getRole());
        }

        throw new UsernameNotFoundException("User not found with id: " + userId);
    }

    private UserDetails buildUserDetails(String email, String password, String role) {
        Collection<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_" + role)); // Spring Security expects roles to start with "ROLE_"

        return new org.springframework.security.core.userdetails.User(
                email,
                password,
                authorities);
    }
}