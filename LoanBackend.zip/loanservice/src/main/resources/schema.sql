CREATE DATABASE IF NOT EXISTS loandb;

USE loandb;

CREATE TABLE loans (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    amount DOUBLE NOT NULL,
    loan_type VARCHAR(255) NOT NULL,
    duration_months INT NOT NULL,
    credit_score INT,
    status VARCHAR(50) NOT NULL,
    field_worker_remarks TEXT,
    risk_score INT,
    risk_recommendation VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Indexes for better performance
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;