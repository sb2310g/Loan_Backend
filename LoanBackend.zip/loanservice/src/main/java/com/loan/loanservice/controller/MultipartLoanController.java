package com.loan.loanservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartException;

import com.loan.loanservice.model.Loan;
import com.loan.loanservice.security.JwtUtil;
import com.loan.loanservice.service.LoanService;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@RestController
@RequestMapping("/multipart")
public class MultipartLoanController {

    private static final Logger logger = LoggerFactory.getLogger(MultipartLoanController.class);

    @Autowired
    private LoanService loanService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping(value = "/loan/create", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Loan> createLoanMultipart(
            @RequestHeader("Authorization") String authorizationHeader,
            @RequestParam @Min(1000) Double amount,
            @RequestParam String loanType,
            @RequestParam @Min(1) @Max(60) Integer durationMonths) {
        
        logger.info("Received loan request - Amount: {}, Type: {}, Duration: {} months", 
                   amount, loanType, durationMonths);
        
        try {
            // Validate authorization header
            if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
                logger.warn("Missing or invalid Authorization header");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
            }
            
            // Extract user info
            String token = authorizationHeader.substring("Bearer ".length());
            String userId = jwtUtil.extractUserId(token);
            String role = jwtUtil.extractRole(token);
            
            logger.debug("Authenticated user - ID: {}, Role: {}", userId, role);
            
            // Create loan
            Loan loan = loanService.createLoan(userId, amount, loanType, durationMonths);
            logger.info("Loan created successfully - ID: {}", loan.getId());
            
            return ResponseEntity.status(HttpStatus.CREATED).body(loan);
            
        } catch (IllegalArgumentException e) {
            logger.error("Authorization error: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        } catch (Exception e) {
            logger.error("Loan creation failed: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<String> handleMultipartError(MultipartException ex) {
        logger.error("Multipart processing error: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body("Invalid multipart request: " + ex.getMessage());
    }
}