
package com.loan.loanservice.service;

import com.loan.loanservice.model.Loan;
import com.loan.loanservice.repository.LoanRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.HashMap;
import java.util.Map;

@Service
public class LoanService {

    private static final Logger logger = LoggerFactory.getLogger(LoanService.class);

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Value("${user.service.base-url}")
    private String userServiceBaseUrl;

    @Value("${risk-analysis-service.base-url}")
    private String riskServiceBaseUrl;

    @Transactional
    public Loan createLoan(String userId, Double amount, String loanType, Integer durationMonths) {
        Loan loan = new Loan();
        loan.setUserId(userId);
        loan.setAmount(amount);
        loan.setLoanType(loanType);
        loan.setDurationMonths(durationMonths);
        loan.setStatus("PENDING");

        // Import credit score from User Service
        Integer creditScore = null;
        try {
            String url = userServiceBaseUrl + "/user/" + userId + "/credit-score";
            creditScore = restTemplate.getForObject(url, Integer.class);
            loan.setCreditScore(creditScore);
            logger.info("Imported credit score: {}", creditScore);
        } catch (Exception e) {
            logger.warn("Could not fetch credit score: {}", e.getMessage());
            // Continue without credit score
        }

        // Initial save to get Loan ID
        Loan savedLoan = loanRepository.save(loan);

        // Risk analysis
        try {
            String riskUrl = String.format(
                "%s/risk/analyze?loanId=%d&userId=%s&amount=%.2f&duration=%d&creditScore=%d",
                riskServiceBaseUrl, savedLoan.getId(), userId, amount, durationMonths, creditScore != null ? creditScore : 0
            );

            RiskAnalysisResult result = restTemplate.getForObject(riskUrl, RiskAnalysisResult.class);

            if (result != null) {
                savedLoan.setRiskScore(result.getRiskScore());
                savedLoan.setRiskRecommendation(result.getRecommendation());
            } else {
                logger.warn("Risk analysis result is null");
                savedLoan.setRiskScore(0);
                savedLoan.setRiskRecommendation("DEFAULT_RISK");
            }

        } catch (HttpClientErrorException e) {
            // Handle specific HTTP errors from risk service
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                logger.error("Risk service: User or loan not found: {}", e.getMessage());
                savedLoan.setStatus("REJECTED");
                savedLoan.setRiskScore(0);
                savedLoan.setRiskRecommendation("RISK_SERVICE_ERROR");
            } else if (e.getStatusCode() == HttpStatus.BAD_REQUEST) {
                logger.error("Risk service: Bad Request: {}", e.getMessage());
                savedLoan.setStatus("REJECTED");
                savedLoan.setRiskScore(0);
                savedLoan.setRiskRecommendation("BAD_REQUEST");
            } else {
                logger.error("Risk service error: {}", e.getMessage());
                savedLoan.setStatus("PENDING");
                savedLoan.setRiskScore(null);
                savedLoan.setRiskRecommendation("RISK_SERVICE_ERROR");
            }
        } catch (Exception e) {
            logger.error("Risk service unavailable: {}", e.getMessage());
            savedLoan.setStatus("PENDING");
            savedLoan.setRiskScore(null);
            savedLoan.setRiskRecommendation("RISK_SERVICE_UNAVAILABLE");
        }

        return loanRepository.save(savedLoan);
    }

    @Transactional
    public void updateLoanRisk(Long loanId, Integer riskScore, String recommendation) {
        if (loanId == null) {
            throw new IllegalArgumentException("Loan ID must not be null");
        }
        if (riskScore == null || riskScore < 0 || riskScore > 10) {
            throw new IllegalArgumentException("Risk score must be between 0 and 10");
        }
        if (recommendation == null || recommendation.isBlank()) {
            throw new IllegalArgumentException("Recommendation must not be empty");
        }

        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new LoanNotFoundException(loanId));

        loan.setRiskScore(riskScore);
        loan.setRiskRecommendation(recommendation);
        loanRepository.save(loan);
        logger.info("Updated risk for loanId: {}, riskScore: {}, recommendation: {}",
                loanId, riskScore, recommendation);
    }

    @Transactional
    public Loan updateLoanRemarks(Long loanId, String remarks, String fieldWorkerId) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new LoanNotFoundException(loanId));
        loan.setFieldWorkerRemarks(remarks);
        loan.setStatus("REVIEWED");
        return loanRepository.save(loan);
    }

    @Transactional
    public Loan updateLoanStatus(Long loanId, String status, String adminId) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new LoanNotFoundException(loanId));

        if (!"REVIEWED".equals(loan.getStatus())) {
            throw new InvalidLoanStatusException("Loan must be in REVIEWED status to be approved/rejected");
        }

        if (!status.equals("APPROVED") && !status.equals("REJECTED")) {
            throw new InvalidLoanStatusException("Invalid Status - only APPROVED or REJECTED allowed");
        }

        loan.setStatus(status);
        return loanRepository.save(loan);
    }

    @Transactional
    public Loan updateLoanStatusToReviewed(Long loanId, String fieldWorkerId) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new LoanNotFoundException(loanId));

        if (!"PENDING".equals(loan.getStatus())) {
            throw new InvalidLoanStatusException(
                "Loan must be in PENDING status to be marked as REVIEWED");
        }

        loan.setStatus("REVIEWED");
        return loanRepository.save(loan);
    }

    public List<Loan> getLoansByStatus(String status) {
        return loanRepository.findByStatus(status);
    }

    public List<Loan> getLoansByUserId(String userId) {
        return loanRepository.findByUserId(userId);
    }
    
    public List<Loan> getAllLoans() {
        return loanRepository.findAll();
    }

    @Transactional
    public void sendLoanForRiskAnalysis(Long loanId) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new LoanNotFoundException(loanId));

        // Prepare the request to the Risk Analysis Microservice
        String riskUrl = String.format(
                "%s/risk/analyze?loanId=%d&userId=%s&amount=%.2f&duration=%d&creditScore=%d",
                riskServiceBaseUrl, loan.getId(), loan.getUserId(), loan.getAmount(), loan.getDurationMonths(),
                loan.getCreditScore() != null ? loan.getCreditScore() : 0
        );

        logger.info("Sending loan for risk analysis: loanId={}, userId={}, amount={}, creditScore={}, durationMonths={}",
                loan.getId(), loan.getUserId(), loan.getAmount(), loan.getCreditScore(), loan.getDurationMonths());

        // Send the request and rely on Risk Analysis Microservice to update via /loan/update-risk
        try {
            RiskAnalysisResult result = restTemplate.getForObject(riskUrl, RiskAnalysisResult.class);
            if (result != null) {
                logger.info("Risk analysis result received: riskScore={}, recommendation={}",
                        result.getRiskScore(), result.getRecommendation());
            } else {
                logger.warn("Risk analysis result is null for loanId: {}", loanId);
            }
        } catch (Exception e) {
            logger.error("Failed to send loan for risk analysis: {}", e.getMessage());
            throw new RuntimeException("Risk analysis service unavailable");
        }
    }

    // DTO and Exceptions
    public static class RiskAnalysisResult {
        private Integer riskScore;
        private String recommendation;

        public Integer getRiskScore() {
            return riskScore;
        }

        public void setRiskScore(Integer riskScore) {
            this.riskScore = riskScore;
        }

        public String getRecommendation() {
            return recommendation;
        }

        public void setRecommendation(String recommendation) {
            this.recommendation = recommendation;
        }

        public RiskAnalysisResult() {} // Default constructor needed for RestTemplate
    }

    public static class LoanNotFoundException extends RuntimeException {
        public LoanNotFoundException(Long loanId) {
            super("Loan not found with ID: " + loanId);
        }
    }

    public static class InvalidLoanStatusException extends RuntimeException {
        public InvalidLoanStatusException(String message) {
            super(message);
        }
    }

    public static class PaymentServiceException extends RuntimeException {
        public PaymentServiceException(String message) {
            super(message);
        }
    }
}