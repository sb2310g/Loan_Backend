package com.loan.loanservice.controller;

import com.loan.loanservice.model.Loan;
import com.loan.loanservice.security.JwtUtil;
import com.loan.loanservice.service.LoanService;
import com.loan.loanservice.service.LoanService.LoanNotFoundException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/loan")
public class LoanController {

    private static final Logger logger = LoggerFactory.getLogger(LoanController.class);

    @Autowired
    private LoanService loanService;

    @Autowired
    private JwtUtil jwtUtil;

    @Value("${loan.api-key}")
    private String apiKey; // Inject the API key from application.properties

    public static class LoanRequest {
        @Valid
        @Min(1000)
        private Double amount;

        @Valid
        @NotBlank
        private String loanType;

        @Valid
        @Min(1)
        @Max(60)
        private Integer durationMonths;

        public Double getAmount() {
            return amount;
        }

        public void setAmount(Double amount) {
            this.amount = amount;
        }

        public String getLoanType() {
            return loanType;
        }

        public void setLoanType(String loanType) {
            this.loanType = loanType;
        }

        public Integer getDurationMonths() {
            return durationMonths;
        }

        public void setDurationMonths(Integer durationMonths) {
            this.durationMonths = durationMonths;
        }
    }

    public static class RiskUpdateRequest {
        @NotBlank
        private Long loanId;

        @Min(0)
        @Max(10)
        private Integer riskScore;

        @NotBlank
        private String recommendation;

        public Long getLoanId() {
            return loanId;
        }

        public void setLoanId(Long loanId) {
            this.loanId = loanId;
        }

        public Integer getRiskScore() {
            return riskScore;
        }

        public void setRiskScore(Integer riskScore) {
            this.riskScore = riskScore;
        }

        public String getRecommendation() {
            return recommendation;
        }

        public void setRecommendation(String recommendation) {
            this.recommendation = recommendation;
        }
    }

    @PostMapping(value = "/create/form", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Loan> createLoanForm(
            HttpServletRequest request,
            @RequestHeader("Authorization") String authorizationHeader,
            @RequestParam("amount") Double amount,
            @RequestParam("loanType") String loanType,
            @RequestParam("durationMonths") Integer durationMonths) {

        logger.debug("Received Content-Type: {}", request.getContentType());
        return processLoanCreation(authorizationHeader, amount, loanType, durationMonths);
    }

    @PostMapping(value = "/create/json", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Loan> createLoanJson(
            @RequestHeader("Authorization") String authorizationHeader,
            @RequestBody @Valid LoanRequest jsonRequest) {

        return processLoanCreation(
                authorizationHeader,
                jsonRequest.getAmount(),
                jsonRequest.getLoanType(),
                jsonRequest.getDurationMonths()
        );
    }

    private ResponseEntity<Loan> processLoanCreation(
            String authorizationHeader,
            Double amount,
            String loanType,
            Integer durationMonths) {

        try {
            String token = authorizationHeader.substring("Bearer ".length());
            String userId = jwtUtil.extractUserId(token);

            logger.info("Creating loan for user {}: amount={}, type={}, duration={} months",
                    userId, amount, loanType, durationMonths);

            Loan loan = loanService.createLoan(userId, amount, loanType, durationMonths);
            return ResponseEntity.status(HttpStatus.CREATED).body(loan);
        } catch (IllegalArgumentException e) {
            logger.error("Authorization error", e);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        } catch (Exception e) {
            logger.error("Processing error", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Loan>> getLoansByUserId(
            @PathVariable String userId,
            @RequestHeader("Authorization") String authHeader) {

        String token = authHeader.substring("Bearer ".length());
        String requestingUserId = jwtUtil.extractUserId(token);
        String role = jwtUtil.extractRole(token);

        if (!"ADMIN".equals(role) && !requestingUserId.equals(userId)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        List<Loan> loans = loanService.getLoansByUserId(userId);
        return ResponseEntity.ok(loans);
    }
    
    @GetMapping("/all")
    public ResponseEntity<List<Loan>> getAllLoans(@RequestHeader("Authorization") String authHeader) {
        String token = authHeader.substring("Bearer ".length());
        String role = jwtUtil.extractRole(token);

        // Allow only ADMIN and FIELD_WORKER roles to access this endpoint
        if (!"ADMIN".equals(role) && !"FIELD_WORKER".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        List<Loan> loans = loanService.getAllLoans();
        return ResponseEntity.ok(loans);
    }
    

    @PutMapping("/remarks/{loanId}")
    public ResponseEntity<Loan> updateLoanRemarks(
            @RequestHeader("Authorization") String authorizationHeader,
            @PathVariable Long loanId,
            @RequestParam String remarks) {
        logger.info("Received request to update remarks for loanId: {}", loanId);
        try {
            logger.debug("Authorization header: {}", authorizationHeader);
            String token = authorizationHeader.substring("Bearer ".length());
            logger.debug("JWT Token: {}", token);
            String userId = jwtUtil.extractUserId(token);
            logger.debug("Extracted userId: {}", userId);
            String role = jwtUtil.extractRole(token);
            logger.debug("Extracted role: {}", role);
            if (!"FIELD_WORKER".equals(role)) {
                logger.warn("Forbidden: User role {} is not FIELD_WORKER", role);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            Loan loan = loanService.updateLoanRemarks(loanId, remarks, userId);
            logger.info("Successfully updated remarks for loanId: {}", loanId);
            return ResponseEntity.ok(loan);
        } catch (IllegalArgumentException e) {
            logger.error("Unauthorized: JWT validation failed", e);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
        } catch (Exception e) {
            logger.error("Bad Request: Error processing remarks for loanId: {}", loanId, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @PutMapping("/{loanId}/status")
    public ResponseEntity<Loan> updateLoanStatus(
            @PathVariable Long loanId,
            @RequestBody Map<String, String> requestBody,
            @RequestHeader("Authorization") String authorizationHeader) {

        try {
            String token = authorizationHeader.substring("Bearer ".length());
            String userId = jwtUtil.extractUserId(token);
            String role = jwtUtil.extractRole(token);

            String newStatus = requestBody.get("status");
            if (newStatus == null) {
                logger.warn("Status update request missing status field");
                return ResponseEntity.badRequest().build();
            }

            Loan updatedLoan;

            if ("ADMIN".equals(role)) {
                if (!"APPROVED".equals(newStatus) && !"REJECTED".equals(newStatus)) {
                    logger.warn("Admin attempted invalid status update: {}", newStatus);
                    return ResponseEntity.badRequest().build();
                }
                updatedLoan = loanService.updateLoanStatus(loanId, newStatus, userId);
                logger.info("Admin {} updated loan {} status to {}", userId, loanId, newStatus);
            } else if ("FIELD_WORKER".equals(role)) {
                if (!"REVIEWED".equals(newStatus)) {
                    logger.warn("Field worker attempted invalid status update: {}", newStatus);
                    return ResponseEntity.badRequest().build();
                }
                updatedLoan = loanService.updateLoanStatusToReviewed(loanId, userId);
                logger.info("Field worker {} updated loan {} status to REVIEWED", userId, loanId);
            } else {
                logger.warn("Unauthorized role attempted status update: {}", role);
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
            }

            return ResponseEntity.ok(updatedLoan);

        } catch (LoanService.LoanNotFoundException e) {
            logger.error("Loan not found: {}", loanId);
            return ResponseEntity.notFound().build();
        } catch (LoanService.InvalidLoanStatusException e) {
            logger.error("Invalid status transition: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            logger.error("Unexpected error updating loan status", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping("/send-for-risk-analysis")
    public ResponseEntity<String> sendForRiskAnalysis(@RequestParam Long loanId) {
        try {
            loanService.sendLoanForRiskAnalysis(loanId);
            return ResponseEntity.ok("Loan sent for risk analysis successfully");
        } catch (LoanNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send loan for risk analysis");
        }
    }

    @PostMapping("/update-risk")
    public ResponseEntity<String> updateLoanRisk(
            @RequestHeader("X-API-Key") String receivedApiKey,
            @RequestBody @Valid RiskUpdateRequest request) {
        try {
            // Validate API key
            if (!apiKey.equals(receivedApiKey)) {
                logger.warn("Invalid API key: {}", receivedApiKey);
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid API key");
            }

            logger.info("Updating risk for loanId: {}, riskScore: {}, recommendation: {}",
                    request.getLoanId(), request.getRiskScore(), request.getRecommendation());

            loanService.updateLoanRisk(
                    request.getLoanId(),
                    request.getRiskScore(),
                    request.getRecommendation()
            );
            return ResponseEntity.ok("Risk data updated successfully");
        } catch (LoanNotFoundException e) {
            logger.error("Loan not found: {}", request.getLoanId());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (IllegalArgumentException e) {
            logger.error("Invalid input: {}", e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            logger.error("Error updating risk data: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error");
        }
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<String> handleMultipartError(MultipartException ex) {
        logger.error("Multipart processing error", ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body("Multipart processing error: " + ex.getMessage());
    }
}
