package com.loan.loanservice.security;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        final String authHeader = request.getHeader("Authorization");
        String jwt = null;
        String userId = null;
        String role = null;

        logger.info("Request URI: {}", request.getRequestURI());
        logger.info("Authorization header: {}", authHeader);

        if (StringUtils.hasText(authHeader) && authHeader.startsWith("Bearer ")) {
            jwt = authHeader.substring(7);
            logger.debug("JWT Token: {}", jwt);
            try {
                userId = jwtUtil.extractUserId(jwt);
                role = jwtUtil.extractRole(jwt);
                logger.info("Extracted userId: {}, role: {}", userId, role);
            } catch (Exception e) { // Catch broader exceptions
                logger.error("Failed to extract claims from JWT: {}", e.getMessage(), e);
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }
        } else {
            logger.warn("Invalid or missing Authorization header");
            filterChain.doFilter(request, response);
            return;
        }

        if (userId != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            try {
                if (jwtUtil.validateToken(jwt)) {
                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(userId, null, getAuthorities(role));
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    logger.info("Authentication set with authorities: {}", authentication.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                } else {
                    logger.warn("JWT token is invalid or expired");
                }
            } catch (Exception e) {
                logger.error("Token validation failed: {}", e.getMessage(), e);
            }
        } else {
            logger.warn("No userId or authentication already exists");
        }
        filterChain.doFilter(request, response);
    }

    private Collection<? extends SimpleGrantedAuthority> getAuthorities(String role) {
        return Arrays.stream(role.split(","))
                .map(r -> new SimpleGrantedAuthority("ROLE_" + r)) // Prefix with ROLE_
                .collect(Collectors.toList());
    }
}