package com.loan.loanservice.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "loans")
public class Loan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotNull
    private String userId;
    @Positive
    private Double amount;
    @NotNull
    private String loanType;
    
    private Integer creditScore;
    
   @Column(nullable = false)
   private Integer durationMonths;
    
    @NotNull
    private String status;
    private String fieldWorkerRemarks;
    private Integer riskScore;
    private String riskRecommendation;

    public Loan() {
    }

    public Loan(String userId, Double amount, String loanType, String status, Integer durationMonths) {
        this.userId = userId;
        this.amount = amount;
        this.loanType = loanType;
        this.status = status;
        this.durationMonths = durationMonths;
    }
    
    public Integer getCreditScore() {
        return creditScore;
    }

    public void setCreditScore(Integer creditScore) {
        this.creditScore = creditScore;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFieldWorkerRemarks() {
        return fieldWorkerRemarks;
    }

    public void setFieldWorkerRemarks(String fieldWorkerRemarks) {
        this.fieldWorkerRemarks = fieldWorkerRemarks;
    }

    public Integer getRiskScore() {
        return riskScore;
    }
    
   public Integer getDurationMonths() { return durationMonths; }
   public void setDurationMonths(Integer durationMonths) { 
       this.durationMonths = durationMonths;
   }

    public void setRiskScore(Integer riskScore) {
        this.riskScore = riskScore;
    }

    public String getRiskRecommendation() {
        return riskRecommendation;
    }

    public void setRiskRecommendation(String riskRecommendation) {
        this.riskRecommendation = riskRecommendation;
    }
}
