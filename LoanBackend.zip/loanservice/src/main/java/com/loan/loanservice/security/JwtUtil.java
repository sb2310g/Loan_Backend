package com.loan.loanservice.security;

import java.util.Date;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class JwtUtil {

    private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);

    private final SecretKey secretKey;

    public JwtUtil(@Value("${jwt.secret}") String jwtSecret) {
        this.secretKey = Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }

    public String extractUserId(String token) {
        logger.debug("Extracting userId from token: {}", token);
        return extractClaim(token, Claims::getSubject);
    }

    public Date extractExpiration(String token) {
        logger.debug("Extracting expiration date from token: {}", token);
        return extractClaim(token, Claims::getExpiration);
    }

    public String extractRole(String token) {
        logger.debug("Extracting role from token: {}", token);
        return extractClaim(token, claims -> claims.get("role", String.class));
    }

    private <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Claims extractAllClaims(String token) {
        try {
            logger.debug("Parsing claims from token: {}", token);
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
            logger.debug("Parsed claims: {}", claims);
            return claims;
        } catch (JwtException e) {
            logger.error("Invalid JWT: {}", e.getMessage());
            throw new JwtException("Invalid JWT: " + e.getMessage());
        }
    }

    public boolean isTokenExpired(String token) {
        boolean expired = extractExpiration(token).before(new Date());
        logger.debug("Token expired: {}", expired);
        return expired;
    }

    public boolean validateToken(String token) {
        try {
            logger.debug("Validating token: {}", token);
            extractAllClaims(token);
            boolean valid = !isTokenExpired(token);
            logger.debug("Token valid: {}", valid);
            return valid;
        } catch (JwtException e) {
            logger.error("Token validation failed: {}", e.getMessage());
            return false;
        }
    }
}
