package com.loan.loanservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
