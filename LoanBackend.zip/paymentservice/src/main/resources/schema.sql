CREATE DATABASE IF NOT EXISTS paymentdb;

USE paymentdb;

CREATE TABLE payments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    loan_id BIGINT NOT NULL,
    amount DOUBLE NOT NULL,
    date DATE NOT NULL
);