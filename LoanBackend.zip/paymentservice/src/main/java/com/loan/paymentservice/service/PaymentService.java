
package com.loan.paymentservice.service;

import com.loan.paymentservice.model.Payment;
import com.loan.paymentservice.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public Payment createPayment(Long userId, Long loanId, Double amount) {
        Payment payment = new Payment(userId, loanId, amount, LocalDate.now());
        return paymentRepository.save(payment);
    }

    public List<Payment> getPaymentsByUserId(Long userId) {
        return paymentRepository.findByUserId(userId);
    }
}