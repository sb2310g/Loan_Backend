package com.loan.riskanalysisservice.controller;

import com.loan.riskanalysisservice.service.RiskAnalysisService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/risk")
public class RiskAnalysisController {
    private static final Logger logger = LoggerFactory.getLogger(RiskAnalysisController.class);
    
    @Autowired
    private RiskAnalysisService riskAnalysisService;
    
    @GetMapping("/analyze")
    public ResponseEntity<?> analyzeLoan(
            @RequestParam Long loanId,
            @RequestParam String userId,
            @RequestParam Double amount,
            @RequestParam Integer duration,
            @RequestParam Integer creditScore) {
        try {
            logger.info("Received risk analysis request: loanId={}, userId={}, amount={}, duration={}, creditScore={}",
                    loanId, userId, amount, duration, creditScore);
            
            RiskAnalysisService.RiskAnalysisResult result = riskAnalysisService.analyzeLoan(loanId, userId, amount, duration, creditScore);
            
            logger.info("Risk analysis completed: score={}, recommendation={}",
                    result.getRiskScore(), result.getRecommendation());
            
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid input: {}", e.getMessage());
            ErrorResponse errorResponse = new ErrorResponse("Invalid input: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        } catch (Exception e) {
            logger.error("Error during risk analysis: {}", e.getMessage(), e);
            ErrorResponse errorResponse = new ErrorResponse("Error during risk analysis: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    // Add an ErrorResponse class to handle error messages
    public static class ErrorResponse {
        private String message;
        
        public ErrorResponse(String message) {
            this.message = message;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
    }
}