package com.loan.riskanalysisservice.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class RiskAnalysisService {

    private static final Logger logger = LoggerFactory.getLogger(RiskAnalysisService.class);

    @Autowired
    private RestTemplate restTemplate;

    @Value("${loan.service.base-url}")
    private String loanServiceBaseUrl;

    @Value("${risk.api-key}")
    private String apiKey;
    
    @Value("${loan.service.jwt-token:}")
    private String jwtToken;

    public RiskAnalysisResult analyzeLoan(Long loanId, String userId, Double amount, Integer duration, Integer creditScore) {
        // Validate inputs
        if (loanId == null) {
            throw new IllegalArgumentException("Loan ID must not be null");
        }
        if (userId == null || userId.isBlank()) {
            throw new IllegalArgumentException("User ID must not be empty");
        }
        if (amount == null || amount < 1000) {
            throw new IllegalArgumentException("Loan amount must be at least 1000");
        }
        if (duration == null || duration < 1 || duration > 60) {
            throw new IllegalArgumentException("Loan duration must be between 1 and 60 months");
        }
        if (creditScore == null || creditScore < 300 || creditScore > 850) {
            throw new IllegalArgumentException("Credit score must be between 300 and 850");
        }

        // Calculate risk score
        int riskScore = calculateRiskScore(creditScore, amount, duration);
        String recommendation = getRecommendation(riskScore);

        // Create result object first in case update to loan service fails
        RiskAnalysisResult result = new RiskAnalysisResult();
        result.setRiskScore(riskScore);
        result.setRecommendation(recommendation);

        // Update loan with risk data
        try {
            String url = loanServiceBaseUrl + "/loan/update-risk";
            HttpHeaders headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            headers.set("X-API-Key", apiKey);
            
            // Add JWT token if available
            if (jwtToken != null && !jwtToken.isBlank()) {
                headers.set("Authorization", "Bearer " + jwtToken);
                logger.debug("Added JWT token to request");
            } else {
                logger.warn("No JWT token available for authentication with loan service");
            }

            RiskUpdateRequest request = new RiskUpdateRequest();
            request.setLoanId(loanId);
            request.setRiskScore(riskScore);
            request.setRecommendation(recommendation);

            logger.info("Sending RiskUpdateRequest to loan service: loanId={}, riskScore={}, recommendation={}",
                    request.getLoanId(), request.getRiskScore(), request.getRecommendation());

            HttpEntity<RiskUpdateRequest> entity = new HttpEntity<>(request, headers);
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                logger.info("Successfully updated loanId: {} with riskScore: {}, recommendation: {}",
                        loanId, riskScore, recommendation);
            } else {
                logger.warn("Unexpected response status: {} when updating loan risk data", response.getStatusCodeValue());
            }
        } catch (HttpClientErrorException e) {
            logger.error("Client error when updating loan risk data: {} - {}", e.getStatusCode(), e.getResponseBodyAsString());
            // Don't throw exception, just return the risk analysis result
            logger.info("Returning risk analysis despite error updating loan service");
        } catch (HttpServerErrorException e) {
            logger.error("Server error when updating loan risk data: {} - {}", e.getStatusCode(), e.getResponseBodyAsString());
            // Don't throw exception, just return the risk analysis result
            logger.info("Returning risk analysis despite error updating loan service");
        } catch (Exception e) {
            logger.error("Failed to update loan risk data for loanId: {} - {}", loanId, e.getMessage());
            // Don't throw exception, just return the risk analysis result
            logger.info("Returning risk analysis despite error updating loan service");
        }

        return result;
    }

    private int calculateRiskScore(int creditScore, Double amount, Integer duration) {
        double creditScoreWeight = 0.5; // 50% weight
        double amountWeight = 0.3;      // 30% weight
        double durationWeight = 0.2;    // 20% weight

        // Credit score component (0-5 points)
        double creditScoreComponent;
        if (creditScore >= 750) {
            creditScoreComponent = 0; // Low risk
        } else if (creditScore >= 650) {
            creditScoreComponent = 2.5; // Medium risk
        } else {
            creditScoreComponent = 5; // High risk
        }

        // Loan amount component (0-3 points)
        double amountComponent;
        if (amount < 10000) {
            amountComponent = 0; // Low risk
        } else if (amount <= 50000) {
            amountComponent = 1.5; // Medium risk
        } else {
            amountComponent = 3; // High risk
        }

        // Duration component (0-2 points)
        double durationComponent;
        if (duration <= 12) {
            durationComponent = 0; // Low risk
        } else if (duration <= 36) {
            durationComponent = 1; // Medium risk
        } else {
            durationComponent = 2; // High risk
        }

        // Weighted sum
        double rawScore = (creditScoreComponent * creditScoreWeight) +
                         (amountComponent * amountWeight) +
                         (durationComponent * durationWeight);

        // Normalize to 0-10 scale
        int finalScore = (int) Math.round(rawScore * 10 / 5); // Max raw score is ~5
        return Math.max(0, Math.min(10, finalScore));
    }

    private String getRecommendation(int riskScore) {
        if (riskScore <= 3) {
            return "Low Risk";
        } else if (riskScore <= 6) {
            return "Low Risk with Caution";
        } else if (riskScore <= 8) {
            return "Moderate Risk";
        } else {
            return "High Risk";
        }
    }

    public static class RiskAnalysisResult {
        private Integer riskScore;
        private String recommendation;

        public Integer getRiskScore() {
            return riskScore;
        }

        public void setRiskScore(Integer riskScore) {
            this.riskScore = riskScore;
        }

        public String getRecommendation() {
            return recommendation;
        }

        public void setRecommendation(String recommendation) {
            this.recommendation = recommendation;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class RiskUpdateRequest {
        private Long loanId;
        private Integer riskScore;
        private String recommendation;

        public Long getLoanId() {
            return loanId;
        }

        public void setLoanId(Long loanId) {
            this.loanId = loanId;
        }

        public Integer getRiskScore() {
            return riskScore;
        }

        public void setRiskScore(Integer riskScore) {
            this.riskScore = riskScore;
        }

        public String getRecommendation() {
            return recommendation;
        }

        public void setRecommendation(String recommendation) {
            this.recommendation = recommendation;
        }
    }
}