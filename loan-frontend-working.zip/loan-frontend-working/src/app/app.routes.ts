import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { LoanCreateComponent } from './components/loan-create/loan-create.component';
import { LoanListComponent } from './components/loan-list/loan-list.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { EmiCalculatorComponent } from './components/emi-calculator/emi-calculator.component'; // Import EMI Calculator
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'loan-create', component: LoanCreateComponent, canActivate: [AuthGuard] },
  { path: 'loans', component: LoanListComponent, canActivate: [AuthGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'emi-calculator', component: EmiCalculatorComponent }, // Add EMI Calculator route
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];