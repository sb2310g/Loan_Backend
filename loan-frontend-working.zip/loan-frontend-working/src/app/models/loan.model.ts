export interface Loan {
    id: number;
    userId: string;
    amount: number;
    loanType: string;
    durationMonths: number;
    creditScore?: number;
    status: string;
    fieldWorkerRemarks?: string;
    riskScore?: number;
    riskRecommendation?: string;
    createdAt?: string;
  }