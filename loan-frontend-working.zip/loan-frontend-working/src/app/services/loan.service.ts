import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Loan } from '../models/loan.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class LoanService {
  private apiUrl = `${environment.apiUrl}/loan`;

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      Authorization: `Bearer ${token || ''}`
    });
  }

  // Create a new loan
  createLoan(loan: { amount: number; loanType: string; durationMonths: number }): Observable<Loan> {
    return this.http.post<Loan>(`${this.apiUrl}/create/json`, loan, { headers: this.getAuthHeaders() });
  }

  // Fetch loans for a specific user
  getLoansByUserId(userId: string): Observable<Loan[]> {
    return this.http.get<Loan[]>(`${this.apiUrl}/user/${userId}`, { headers: this.getAuthHeaders() });
  }

  // Fetch all loans (for ADMIN or FIELD_WORKER roles)
  getAllLoans(): Observable<Loan[]> {
    return this.http.get<Loan[]>(`${this.apiUrl}/all`, { headers: this.getAuthHeaders() });
  }

  // Update loan remarks (for FIELD_WORKER role)
  updateLoanRemarks(loanId: number, remarks: string): Observable<Loan> {
    const params = new HttpParams().set('remarks', remarks); // Use HttpParams for query parameters
    return this.http.put<Loan>(`${this.apiUrl}/remarks/${loanId}`, null, {
      headers: this.getAuthHeaders(),
      params: params
    });
  }

  // Update loan status (for ADMIN or FIELD_WORKER roles)
  updateLoanStatus(loanId: number, status: string): Observable<Loan> {
    return this.http.put<Loan>(
      `${this.apiUrl}/${loanId}/status`,
      { status },
      { headers: this.getAuthHeaders() }
    );
  }

  // Send a loan for risk analysis
  sendForRiskAnalysis(loanId: number): Observable<string> {
    return this.http.post<string>(
      `${this.apiUrl}/send-for-risk-analysis`,
      { loanId }, // Ensure the backend expects this field name
      { headers: this.getAuthHeaders() }
    );
  }

  // Approve a loan (for ADMIN role)
  approveLoan(loanId: number): Observable<Loan> {
    return this.http.put<Loan>(
      `${this.apiUrl}/${loanId}/status`,
      { status: 'APPROVED' },
      { headers: this.getAuthHeaders() }
    );
  }

  // Reject a loan (for ADMIN role)
  rejectLoan(loanId: number): Observable<Loan> {
    return this.http.put<Loan>(
      `${this.apiUrl}/${loanId}/status`,
      { status: 'REJECTED' },
      { headers: this.getAuthHeaders() }
    );
  }
}