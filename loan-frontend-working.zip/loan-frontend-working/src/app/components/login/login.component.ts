import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  credentials = { email: '', password: '' };
  errorMessage: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  login(): void {
    this.authService.login(this.credentials).subscribe({
      next: (token) => {
        this.authService.saveToken(token);
        const role = this.authService.getRole();
        if (role === 'ADMIN' || role === 'FIELD_WORKER') {
          this.router.navigate(['/dashboard']);
        } else {
          this.router.navigate(['/loans']);
        }
      },
      error: (err) => {
        this.errorMessage = 'Invalid credentials';
        console.error(err);
      }
    });
  }
}