import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  user = {
    name: '',
    email: '',
    password: '',
    role: 'USER',
    pin: undefined as string | undefined,
    creditScore: undefined as number | undefined
  };
  errorMessage: string | null = null;

  constructor(private authService: AuthService, private router: Router) {}

  signup(): void {
    // Validate inputs based on role
    if (!this.user.name || !this.user.email || !this.user.password || !this.user.role) {
      this.errorMessage = 'All required fields must be filled';
      return;
    }

    if (this.user.role === 'USER') {
      if (!this.user.creditScore || this.user.creditScore < 300 || this.user.creditScore > 850) {
        this.errorMessage = 'Credit score must be between 300 and 850';
        return;
      }
    } else if (this.user.role === 'ADMIN' || this.user.role === 'FIELD_WORKER') {
      if (!this.user.pin) {
        this.errorMessage = 'PIN is required for Admin or Field Worker';
        return;
      }
    }

    this.authService.signup(this.user).subscribe({
      next: () => {
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.errorMessage = err.error.message || 'Signup failed';
        console.error(err);
      }
    });
  }
}