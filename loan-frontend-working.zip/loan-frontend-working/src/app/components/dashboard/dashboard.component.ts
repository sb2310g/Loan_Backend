import { Component, OnInit } from '@angular/core';
import { LoanService } from '../../services/loan.service';
import { AuthService } from '../../services/auth.service';
import { Loan } from '../../models/loan.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  loans: Loan[] = [];
  filteredLoans: Loan[] = [];
  role: string | null = null;
  userId: string | null = null;

  constructor(private loanService: LoanService, private authService: AuthService) {}

  ngOnInit(): void {
    this.role = this.authService.getRole();
    this.userId = this.authService.getUserId();

    // Fetch all loans initially
    this.loanService.getAllLoans().subscribe({
      next: (loans) => {
        this.loans = loans;
        this.filterLoansByRole(); // Filter loans based on the user's role
      },
      error: (err) => {
        console.error('Error fetching loans:', err);
      }
    });
  }

  filterLoansByRole(): void {
    if (this.role === 'FIELD_WORKER') {
      // Field Worker can see both PENDING and REVIEWED loans
      this.filteredLoans = this.loans.filter(
        (loan) => loan.status === 'PENDING' || loan.status === 'REVIEWED'
      );
    } else if (this.role === 'ADMIN') {
      // Admin can see APPROVED, REJECTED, and REVIEWED loans
      this.filteredLoans = this.loans.filter(
        (loan) =>
          loan.status === 'APPROVED' ||
          loan.status === 'REJECTED' ||
          loan.status === 'REVIEWED'
      );
    } else {
      // Default to an empty list for other roles
      this.filteredLoans = [];
    }
  }

  addRemark(loanId: number): void {
    const loan = this.filteredLoans.find((l) => l.id === loanId);
    if (loan && loan.fieldWorkerRemarks) {
      this.loanService.updateLoanRemarks(loanId, loan.fieldWorkerRemarks).subscribe({
        next: (updatedLoan) => {
          loan.fieldWorkerRemarks = updatedLoan.fieldWorkerRemarks; // Update the remarks in the UI
        },
        error: (err) => {
          console.error('Error adding remark:', err);
        }
      });
    }
  }

  changeStatusToReviewed(loanId: number): void {
    const loan = this.filteredLoans.find((l) => l.id === loanId);
    if (loan) {
      this.loanService.updateLoanStatus(loanId, 'REVIEWED').subscribe({
        next: () => {
          loan.status = 'REVIEWED';
          this.filterLoansByRole(); // Re-filter loans after status change
        },
        error: (err) => {
          console.error('Error changing status to REVIEWED:', err);
        }
      });
    }
  }

  approveLoan(loanId: number): void {
    const loan = this.filteredLoans.find((l) => l.id === loanId);
    if (loan) {
      this.loanService.approveLoan(loanId).subscribe({
        next: () => {
          loan.status = 'APPROVED';
        },
        error: (err) => {
          console.error('Error approving loan:', err);
        }
      });
    }
  }

  rejectLoan(loanId: number): void {
    const loan = this.filteredLoans.find((l) => l.id === loanId);
    if (loan) {
      this.loanService.rejectLoan(loanId).subscribe({
        next: () => {
          loan.status = 'REJECTED';
        },
        error: (err) => {
          console.error('Error rejecting loan:', err);
        }
      });
    }
  }
}