import { Component, OnInit } from '@angular/core';
import { LoanService } from '../../services/loan.service';
import { AuthService } from '../../services/auth.service';
import { Loan } from '../../models/loan.model';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-loan-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './loan-list.component.html',
  styleUrls: ['./loan-list.component.css']
})
export class LoanListComponent implements OnInit {
  loans: Loan[] = [];
  errorMessage: string | null = null;

  constructor(private loanService: LoanService, private authService: AuthService) {}

  ngOnInit(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.loanService.getLoansByUserId(userId).subscribe({
        next: (loans) => {
          this.loans = loans;
        },
        error: (err) => {
          this.errorMessage = 'Failed to load loans';
          console.error(err);
        }
      });
    }
  }
}