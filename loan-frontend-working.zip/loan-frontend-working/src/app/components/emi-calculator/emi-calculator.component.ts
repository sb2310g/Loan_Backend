import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-emi-calculator',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './emi-calculator.component.html',
  styleUrls: ['./emi-calculator.component.css']
})
export class EmiCalculatorComponent {
  loanAmount: number = 0;
  interestRate: number = 0;
  tenure: number = 0; // in months
  emi: number | null = null;

  calculateEMI(): void {
    const monthlyRate = this.interestRate / 12 / 100;
    const numerator = this.loanAmount * monthlyRate * Math.pow(1 + monthlyRate, this.tenure);
    const denominator = Math.pow(1 + monthlyRate, this.tenure) - 1;
    this.emi = numerator / denominator;
  }
}

// Export the route for this component
export const EmiCalculatorRoute = {
  path: 'emi-calculator',
  component: EmiCalculatorComponent
};
