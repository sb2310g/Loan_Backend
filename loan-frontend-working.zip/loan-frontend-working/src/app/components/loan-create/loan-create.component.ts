import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoanService } from '../../services/loan.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-loan-create',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './loan-create.component.html',
  styleUrls: ['./loan-create.component.css']
})
export class LoanCreateComponent {
  loan = {
    amount: 0,
    loanType: 'PERSONAL',
    durationMonths: 0
  };
  errorMessage: string | null = null;

  constructor(private loanService: LoanService, private router: Router) {}

  createLoan(): void {
    // Validate inputs
    if (!this.loan.amount || this.loan.amount <= 0) {
      this.errorMessage = 'Loan amount must be a positive number';
      return;
    }
    if (!this.loan.durationMonths || this.loan.durationMonths <= 0) {
      this.errorMessage = 'Loan duration must be a positive number';
      return;
    }
    if (!this.loan.loanType) {
      this.errorMessage = 'Loan type is required';
      return;
    }

    this.loanService.createLoan(this.loan).subscribe({
      next: () => {
        this.router.navigate(['/loans']);
      },
      error: (err) => {
        this.errorMessage = err.error.message || 'Loan creation failed';
        console.error(err);
      }
    });
  }
}