import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
import { provideRouter, Routes } from '@angular/router';
import { EmiCalculatorRoute } from './app/components/emi-calculator/emi-calculator.component';

const routes: Routes = [
  { path: '', component: AppComponent },
  EmiCalculatorRoute, // Add the EMI Calculator route here
];

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));